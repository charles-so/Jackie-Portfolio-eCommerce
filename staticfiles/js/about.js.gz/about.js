document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("button2coaching").onclick = function () {
        window.location.href = "/coaching";
    };

    document.getElementById("button2tools").onclick = function () {
        window.location.href = "/productservice";
    };
});
