document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("bookNow").addEventListener("click", function () {
        window.open("https://jktradings.charleso.site/jacky", "_blank");
    });
});