document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("bookNow").addEventListener("click", function () {
        window.open("https://jktradingscal.charleso.site/jacky", "_blank");
    });
});